
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Database = require('@replit/database');

const app = express();
const db = new Database();

// Armazenamento temporário para postagens do preview
let temporaryPosts = [];

// Configuração do multer para upload de imagens
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public/uploads/')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname)
  }
});
const upload = multer({ storage: storage });

// Middleware
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));
app.use(session({
  secret: 'minha-namorada-secret-key-2024',
  resave: false,
  saveUninitialized: true
}));

// Configuração do admin
let adminUser = {
  username: 'amandaellen',
  password: '$2b$10$Kz9ji6ezjXyqKHgGEsx1veA61iZoDsLSs0HWDY3ciKnc6xA9kSps2' // 02042007
};

// Funções para banco de dados
async function getPosts() {
  try {
    const posts = await db.get('posts');
    const result = Array.isArray(posts) ? posts : [];
    console.log('Posts recuperados do banco:', result.length);
    return result;
  } catch (error) {
    console.error('Erro ao buscar posts:', error);
    return [];
  }
}


async function savePosts(posts) {
  try {
    console.log('Salvando posts:', JSON.stringify(posts)); // <- ADICIONE ISSO
    await db.set('posts', posts);
    console.log('Posts salvos com sucesso:', posts.length);
  } catch (error) {
    console.error('Erro ao salvar posts:', error);
    throw error;
  }
}

async function getComments(postId) {
  try {
    const comments = await db.get(`comments_${postId}`);
    return comments || [];
  } catch (error) {
    return [];
  }
}

async function saveComment(postId, comment) {
  const comments = await getComments(postId);
  comments.push(comment);
  await db.set(`comments_${postId}`, comments);
}

// Middleware de autenticação
function requireAuth(req, res, next) {
  if (req.session.authenticated) {
    next();
  } else {
    res.redirect('/admin-login');
  }
}

// Criar diretório de uploads se não existir
if (!fs.existsSync('public/uploads')) {
  fs.mkdirSync('public/uploads', { recursive: true });
}

// Inicializar banco de dados
async function initDatabase() {
    try {
        const posts = await db.get('posts');
        if (posts === undefined || posts === null) { // Corrigido para verificar valores null
            await db.set('posts', []);
            console.log('Banco de dados inicializado com array vazio');
        } else {
            console.log('Banco de dados já inicializado com', Array.isArray(posts) ? posts.length : 0, 'posts');
        }
    } catch (error) {
        console.error('Erro ao inicializar banco:', error);
        await db.set('posts', []);
    }
}

// Chamar inicialização
initDatabase();

// Rotas
app.get('/', async (req, res) => {
  const posts = await getPosts();
  console.log('Posts recuperados na rota inicial:', posts); // Logar posts recuperados
  const sortedPosts = posts.length > 0 ? [...posts].reverse() : [];
  res.render('index', { posts: sortedPosts });
});

app.get('/admin-login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/admin-login', (req, res) => {
  const { username, password } = req.body;
  
  if (username === adminUser.username && bcrypt.compareSync(password, adminUser.password)) {
    req.session.authenticated = true;
    res.redirect('/admin');
  } else {
    res.render('login', { error: 'Credenciais inválidas' });
  }
});

app.get('/admin', requireAuth, async (req, res) => {
  const posts = await getPosts();
  res.render('admin', { posts: Array.isArray(posts) ? posts : [] });
});

app.post('/admin/new-post', requireAuth, upload.single('image'), async (req, res) => {
    try {
        const { title, content } = req.body;
        console.log('Criando novo post:', { title, content });

        let posts = await getPosts();
        if (!Array.isArray(posts)) {
            posts = [];
        }

        const newPost = {
            id: Date.now(),
            title,
            content,
            image: req.file ? `/uploads/${req.file.filename}` : null,
            date: new Date().toLocaleDateString('pt-BR')
        };

        posts.push(newPost);
        await savePosts(posts);

        console.log('Posts após salvar:', await getPosts()); // Log pós salvamento

        res.redirect('/admin');
    } catch (error) {
        console.error('Erro ao criar post:', error);
        res.status(500).send('Erro interno do servidor');
    }
});

app.post('/admin/delete-post/:id', requireAuth, async (req, res) => {
  const postId = parseInt(req.params.id);
  let posts = await getPosts();
  
  // Garantir que posts é um array
  if (!Array.isArray(posts)) {
    posts = [];
  }
  
  const filteredPosts = posts.filter(post => post.id !== postId);
  await savePosts(filteredPosts);
  res.redirect('/admin');
});

// Rota para criar postagens temporárias (preview)
app.post('/preview/new-post', requireAuth, upload.single('image'), async (req, res) => {
  const { title, content } = req.body;
  const newPost = {
    id: Date.now(),
    title,
    content,
    image: req.file ? `/uploads/${req.file.filename}` : null,
    date: new Date().toLocaleDateString('pt-BR')
  };
  temporaryPosts.push(newPost);
  res.redirect('/preview');
});

// Rota para visualizar postagens temporárias
app.get('/preview', async (req, res) => {
  const permanentPosts = await getPosts();
  const allPosts = [...permanentPosts, ...temporaryPosts];
  const sortedPosts = allPosts.length > 0 ? [...allPosts].reverse() : [];
  res.render('preview', { posts: sortedPosts, temporaryCount: temporaryPosts.length });
});

//rota de teste db

app.get('/ver-posts-db', async (req, res) => {
  const posts = await db.get('posts');
  res.json(posts);
});

// Rota para tornar postagens temporárias permanentes
app.post('/preview/make-permanent', requireAuth, async (req, res) => {
    try {
        console.log('Tentando tornar permanente:', temporaryPosts.length, 'posts');

        if (temporaryPosts.length > 0) {
            let posts = await getPosts();
            if (!Array.isArray(posts)) {
                posts = [];
            }

            posts.push(...temporaryPosts);
            await savePosts(posts);
            console.log('Posts tornados permanentes:', posts.length);

            temporaryPosts = [];
            console.log('Posts temporários limpos');
        }
        res.redirect('/admin');
    } catch (error) {
        console.error('Erro ao tornar posts permanentes:', error);
        res.status(500).send('Erro interno do servidor');
    }
});

// Rota para limpar postagens temporárias
app.post('/preview/clear-temporary', requireAuth, async (req, res) => {
  temporaryPosts = [];
  res.redirect('/preview');
});

// Rota para visualizar post individual (permanente)
app.get('/post/:id', async (req, res) => {
  const postId = parseInt(req.params.id);
  const posts = await getPosts();
  const post = posts.find(p => p.id === postId);
  
  if (!post) {
    return res.redirect('/');
  }
  
  const postComments = await getComments(postId);
  res.render('post', { post, comments: postComments, isTemporary: false });
});

// Rota para visualizar post temporário individual
app.get('/preview/post/:id', (req, res) => {
  const postId = parseInt(req.params.id);
  const post = temporaryPosts.find(p => p.id === postId);
  
  if (!post) {
    return res.redirect('/preview');
  }
  
  // Para postagens temporárias, não salvamos comentários no banco
  const temporaryComments = [];
  res.render('post', { post, comments: temporaryComments, isTemporary: true });
});

// Rota para adicionar comentário
app.post('/post/:id/comment', async (req, res) => {
  const postId = parseInt(req.params.id);
  const { name, content } = req.body;
  
  const newComment = {
    id: Date.now(),
    name: name || 'Anônimo',
    content,
    date: new Date().toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  };
  
  await saveComment(postId, newComment);
  res.redirect(`/post/${postId}`);
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

app.listen(5000, '0.0.0.0', () => {
  console.log('Blog rodando na porta 5000');
});
